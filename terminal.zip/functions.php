<?php

add_action('wp_ajax_get_ajax_posts', 'get_ajax_posts');
add_action('wp_ajax_nopriv_get_ajax_posts', 'get_ajax_posts');

function get_ajax_posts() {
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: Content-Type, origin");

    $recent_posts = wp_get_recent_posts(array(
        'numberposts' => 10, // Number of recent posts thumbnails to display
        'post_status' => 'publish' // Show only the published posts
    ));

    $response = [];
    foreach($recent_posts as $post) {
        $response[] = [
            "title" => $post['post_title'],
            "url" => get_permalink( $post['ID'] )
        ];
    }

    echo json_encode( $response );
    wp_die();
}


add_action('wp_ajax_get_ajax_post', 'get_ajax_post');
add_action('wp_ajax_nopriv_get_ajax_post', 'get_ajax_post');

function get_ajax_post() {
    echo json_encode( get_post($_POST['post']) );
    wp_die();
}